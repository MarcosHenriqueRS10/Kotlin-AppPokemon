package br.com.fiap.checkpoint

import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.com.fiap.checkpoint.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btEnviar.setOnClickListener {
            if (binding.containerFormulario.visibility == View.VISIBLE) {
                exibirPokemonSelecionado()
            } else {
                mostrarFormulario()
            }
        }
    }

    private fun mostrarFormulario() {
        binding.containerFormulario.visibility = View.VISIBLE
        binding.containerPokemon.visibility = View.GONE
        binding.btEnviar.text = getString(R.string.label_enviar)

        binding.etNome.setText("")
        binding.spTipos.setSelection(0)
        binding.rgCidade.clearCheck()
        binding.cbBatalha.isChecked = false
        binding.cbCaptura.isChecked = false
        binding.cbEstrategia.isChecked = false
        binding.cbExploracao.isChecked = false
    }

    private fun exibirPokemonSelecionado() {

        binding.containerFormulario.visibility = View.GONE
        binding.containerPokemon.visibility = View.VISIBLE
        binding.btEnviar.text = getString(R.string.label_voltar)

        binding.tvNomeTreinador.text = binding.etNome.text.toString()

        val pokemonSelecionado = binding.spTipos.selectedItem

        val cidadeSelecionada = binding.rgCidade.checkedRadioButtonId

        when (pokemonSelecionado) {

            getString(R.string.label_grama) -> {

                when (cidadeSelecionada) {
                    binding.rbJohto.id -> setPokemon(
                        getString(R.string.chikorita),
                        R.drawable.chikorita
                    )

                    binding.rbKanto.id -> setPokemon(
                        getString(R.string.bulbassaur),
                        R.drawable.bulbassaur
                    )
                }
            }

            getString(R.string.label_fogo) -> {
                when (cidadeSelecionada) {
                    binding.rbJohto.id -> setPokemon(
                        getString(R.string.cyndaquil),
                        R.drawable.cyndaquill
                    )

                    binding.rbKanto.id -> setPokemon(
                        getString(R.string.charmander),
                        R.drawable.charmander
                    )
                }
            }

            getString(R.string.label_eletrico) -> {
                setPokemon(getString(R.string.pikachu), R.drawable.pikachu)
            }

            getString(R.string.label_agua) -> {
                when (cidadeSelecionada) {
                    binding.rbJohto.id -> setPokemon(
                        getString(R.string.totodille),
                        R.drawable.totodile
                    )

                    binding.rbKanto.id -> setPokemon(
                        getString(R.string.squirtle),
                        R.drawable.squirtle
                    )
                }
            }
        }
    }

    private fun setPokemon(nome: String, imagemId: Int) {
        binding.ivPokemon.setImageDrawable(ContextCompat.getDrawable(this, imagemId))
        binding.tvNomePokemon.text = nome
    }

}
